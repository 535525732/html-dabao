# 世界电台

## 信息
- 包名: com.zhongziqing.shijidiantai
- 版本: 1.0.0
- 最小SDK: 23

## 本地编译
用 Android Studio 打开 → Build → Build APK(s)

## GitHub Actions 编译
1. GitHub 新建空仓库
2. `git init && git add . && git commit -m init`
3. `git remote add origin <仓库地址>`
4. `git push -u origin main`
5. Actions 页自动运行 → Artifacts 下载 APK
